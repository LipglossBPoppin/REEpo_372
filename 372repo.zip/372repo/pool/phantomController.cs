using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*********************************
 * Created By Joshua Luis Guzman aka Lipgloss B Poppin
 * this is a script for the phantom Npcs that populate the overworld locations
 *  to be used with objects that need a single ANIMATION
 * 
 * last Moddified:12/26/2021 
 */
public class phantomController : MonoBehaviour
{
    [SerializeField]    float MaxSpeed;
    [SerializeField]    float MinSpeed;
    [SerializeField]    int maxPhan;
    [SerializeField]    int LOWER_TIME_LIMIT;
    [SerializeField]    int UPPER_TIME_LIMIT;

    [Header("THIS MATERIAL NEEDS TOBE FADE OR TRANSPARENT PLEASE")]    [SerializeField]    Material material;
    [SerializeField]    GameObject[] mesh;
    [Header("cells correspond to mesh cells")]    [SerializeField]    textureHolder[] meshTextureObjects;

    [SerializeField]    phantomPath[] phantomPathObjects;


    private List<Queue<Vector3>> paths = new List<Queue<Vector3>>();
    private Queue<phantomScript>[] pool;

    //private Queue<int> meshText;

    //------------------------------------------------------------------------------------for setting al the variables--------------------------------------------------------------------------------------------------------------

    void createPaths()
    {
        for (int i=0;i<phantomPathObjects.Length;i++)
        {
            paths.Add(phantomPathObjects[i].getPath());//eww gross
            //Debug.Log(phantomPathObjects[i].getPath().Count);
        }

    }



    void instantiatePhantoms()
    {//hmmm could do brackeys dictionary of queues hmmm or not a queue at all hmmmmm
     ////       idk sleep on it bitch
        int fl = (int)Mathf.Floor(maxPhan / mesh.Length);
        int rem = maxPhan % fl;

        //meshText = new Queue<int>();
        for (int j = 0; j < mesh.Length; j++)
        {
            pool[j] = new Queue<phantomScript>();

            phantomScript p;
            if (j == mesh.Length - 1)
            {
                fl += rem;
            }
            for (int i = 0; i < fl; i++)
            {
                int temp = ran(this.mesh.Length);
                GameObject obj = Instantiate(mesh[temp]);
                p = obj.GetComponent<phantomScript>();
                //meshText.Enqueue(temp);//ew gross fix this like do anything better idiot

                pool[j].Enqueue(p);

            }
        }
    }

    //------------------------------------------------------------------------------------for setting al the variables-------------------------------------------------------------------------------------------//


    //radnom nuymber genertae
    int ran(int max)
    {
        int en = (int)Mathf.Floor(UnityEngine.Random.value * max);

        return en;
    }

    //anotjher random genearateor
    float ran(float max, float min)
    {
        float en = Mathf.Floor(UnityEngine.Random.value *  (max-min)) + min;

        return en;
    }


    /********************************
    *deques then requesesseseseses already instantiated game object
    *
     */
    IEnumerator setPhantom(ushort num)
    {

        // our local random variables
        int temp2 = ran(this.meshTextureObjects[num].textures.Length);//our specific texture
        int temp3 = ran(this.paths.Count);//our path 

        phantomScript p = pool[num].Dequeue();//this is our skelly we are working on

   
        p.setMove(paths[temp3]);
       
        p.setSpeed(ran(MaxSpeed,MinSpeed));
        p.setMaterial(material);//material must be added before texture!!!!!
        p.setTexture(this.meshTextureObjects[num].textures[temp2]);

        p.gameObject.SetActive(true);//hmm

        //must re-enque stupid
        pool[num].Enqueue(p);

        //wait for amount
        float time = ran(UPPER_TIME_LIMIT, LOWER_TIME_LIMIT);
        yield return new WaitForSeconds(time);

        //we go AGAAAAAAAIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIn
        StartCoroutine(goAgain());
        //meshText.Enqueue(temp);
    }

   
    IEnumerator goAgain()
    {//this logic is a nightmare to look at
        ushort nNum = (ushort)ran(pool.Length);
        //Debug.Log("pure " + nNum+ " "+ pool[nNum].Peek().isActiveAndEnabled);

        if (pool[nNum].Peek().isActiveAndEnabled)
        {
            ushort tempN = 0;
            for (; !pool[tempN].Peek().isActiveAndEnabled && (tempN < pool.Length - 1); tempN++) ;

            if (!pool[tempN].Peek().isActiveAndEnabled)
                nNum = tempN;
            else
                yield return new WaitWhile(() => pool[nNum].Peek().isActiveAndEnabled);

        }

        //Debug.Log(nNum);
        StartCoroutine(setPhantom(nNum));
    }
    
    /*
    void Update()//i hate you
    {

        if (timeUntilNewPhantom < 0)
            if (!phantomQueue.Peek().activeInHierarchy)
            {
                setPhantom();


                timeUntilNewPhantom = (int)ran(UPPER_TIME_LIMIT) + LOWER_TIME_LIMIT;
            }
            else
                timeUntilNewPhantom = LOWER_TIME_LIMIT;

        timeUntilNewPhantom -= Time.deltaTime;
    }
    */

    // Start is called before the first frame update
    void Start()
    {

        pool = new Queue<phantomScript>[mesh.Length];

        createPaths();

        instantiatePhantoms();


        StartCoroutine(setPhantom(0));
    }

}
