
using System.Collections.Generic;
using UnityEngine;


[CreateAssetMenu(fileName = "new Player Inventory", menuName = "Player Inventory")]
public class playerInventory : ScriptableObject
{
    public delegate void textChange(string f);
    public static event textChange Money;
    public static event textChange Added;

    const float MONEY_MAX = 999999.99f;

    [SerializeField]
    float wallet;
    [SerializeField]
    List<Item> items;
    [SerializeField]
    List<ushort> numItem;
    //Dictionary<ushort, ushort> inventory;

    public  void startInventory()
    {
        if (wallet < 0 )
        {
            wallet = 55;
        }
        if (items == null)
        {
            items = new List<Item>();
            numItem = new List<ushort>();
        }

    }

    public float getFunds()
    {
        return wallet;
    }


    public bool removeFunds(float u)
    {
        if (wallet > u)
        {
            wallet -= u;
            Money("-$" + u.ToString("f2"));
            return true;
        }
        return false;
    }

    public void addFunds(float u)
    {
        if (wallet + u >= MONEY_MAX)
            wallet = MONEY_MAX;
        else
            wallet += u;
        Money("+$" + u.ToString("f2"));
       
    }


    public ushort checkItem(Item u)
    {

        if (items.Contains(u))
            return numItem[items.IndexOf(u)];
        return 0;
    }


    public void addItem(Item u,ushort n)
    {
        if (items.Contains(u))
        {
            numItem[items.IndexOf(u)] += n;
         
        }
        else
        {
            items.Add(u);
            numItem.Add(n);
            
        }
        Added(u.name + " x" + n);
    }

}
