using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "new Heal Item", menuName = "Item/Usable Item/Heal Item")]
public class healItem : usableItem
{

    [SerializeField]
    float amount;

    // Start is called before the first frame update
    public override void use(GameObject player)
    {
        //player.GetComponent<playerStatus>().increaseHealth(amount);
    }
}
