using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class usableItem : Item
{


    public abstract void use(GameObject player);

}
