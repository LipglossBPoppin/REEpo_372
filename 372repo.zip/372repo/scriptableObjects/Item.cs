using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Item : ScriptableObject
{
    [SerializeField]
    string itemName;

    [SerializeField]
    string itemDescription;

    [SerializeField]
    bool[] kevin;

    public string getItemName() { return itemName; }


    public string getItemDescription() { return itemDescription; }
}
