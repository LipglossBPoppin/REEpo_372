using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class shop : interactableNPC
{
    [SerializeField]
    blockPlayerMovement playerInput;
    [SerializeField]
    playerInventory pInventory;
    [SerializeField]
    shopInventory sInventory;

    [SerializeField]
    interactableUI interaction;

    [Header("At least shup ui and buy")]
    [SerializeField]
    Canvas[] shopUIs;
    [Header("These will be selected when moving to this ui canvas layer")]
    [SerializeField]
    GameObject[] slectedItems;
    [SerializeField]
    Canvas gameHud;
    [Header("0 #items in machine 1 #items on player 2 cost 3 cost multiplied my amount bought")]
    [SerializeField]
    GameObject changeTextsPublic;//0 #items in machine 1 #items on player 2 cost 3 cost multiplied my amount bought
    [SerializeField]
    InputField numberBuyInput;
    [SerializeField]
    Text t;
    [SerializeField]
    Text shopItemDescription;


    //public List<Button> shops;
    Text[] vendingTexts;

    //public Texture2D cursor;

    private bool shopping = false;
    private ushort uiIndex = 0;
    private ushort itemId = 0;
    private ushort numItem = 0;
   

    public void incrementUI(bool t)
    {
        if (uiIndex + 1 < shopUIs.Length)
        {
            if (t)
                shopUIs[uiIndex].enabled = false;

            uiIndex++;
            shopUIs[uiIndex].enabled = true;

            var eventSystem = EventSystem.current;
            eventSystem.SetSelectedGameObject(slectedItems[uiIndex], new BaseEventData(eventSystem));

        }
    }


    public void jumpEnableUI(ushort u, bool t)
    {
        if (t)
            for (int i = 0; shopUIs[i].enabled && i < u; i++)
                shopUIs[i].enabled = false;

        uiIndex = u;
        shopUIs[uiIndex].enabled = true;
    }

    public void resetUi()
    {
        ushort i = 0;
        for (; shopUIs[i].enabled; i++) ;
        uiIndex = (ushort)(i-1);

    }

    public void decrementUI()
    {
        if (uiIndex > 0)
        {
            shopUIs[uiIndex].enabled = false;
            resetUi();
            var eventSystem = EventSystem.current;
            eventSystem.SetSelectedGameObject(slectedItems[uiIndex], new BaseEventData(eventSystem));
        }
        else
            exitShop();
    }

    // Start is called before the first frame update

    public void setNumber()
    {

        if (numberBuyInput.text != null)
        {
            ushort temp = ushort.Parse(numberBuyInput.text);
            Item tempItem = sInventory.getItem(itemId);
            ushort tempNumItem = sInventory.getNumItem(itemId);

            if (temp + pInventory.checkItem(tempItem) > 99)
            {
                numItem = (ushort)(99 - pInventory.checkItem(tempItem));
                numberBuyInput.text = numItem + "";
                Debug.Log("too many for inventory");
            }
            else
                numItem = temp;

            if (numItem > tempNumItem)
            {
                numItem = tempNumItem;
                numberBuyInput.text = tempNumItem + "";
                Debug.Log("too many for machine");
            }

            float itemCost = sInventory.getCost(itemId);
            float cost = numItem * itemCost;

            if (pInventory.getFunds() < cost)
            {
                numItem = (ushort)(Mathf.Floor(pInventory.getFunds() / itemCost));
                numberBuyInput.text = numItem + "";
                cost = numItem * itemCost;
            }



            vendingTexts[3].text = "$" + cost.ToString("f2");
        }
        else
            numberBuyInput.text = "$" + 0.ToString("f2");
    }

    public void buyItem()
    {
        if (numItem > 0)
        {
            float cost = sInventory.getCost(itemId);
            Item f = sInventory.getItem(itemId);

            if (pInventory.getFunds() >= (numItem * cost))
            {
                sInventory.lowerNumItem(itemId, numItem);
                setNumber();
                pInventory.addItem(f, numItem);

                pInventory.removeFunds((numItem * cost));
                decrementUI();
                numberBuyInput.text = "$" + 0.ToString("f2");

            }
            else
                Debug.Log("NOT ENOUGH MONEY");
        }
    }

    public void setItem(int u)
    {
        itemId = (ushort)u;

        if (sInventory.getNumItem(itemId) > 0)
        {
            vendingTexts[0].text = sInventory.getNumItem(itemId) + "";
            vendingTexts[1].text = pInventory.checkItem(sInventory.getItem(itemId)) + "";
            vendingTexts[2].text = "$"+sInventory.getCost(itemId).ToString("f2");
            vendingTexts[3].text = "$" + 0.ToString("f2");
            //numItem = 1;
        }

    }

    public void setDescription(string u)
    {
        shopItemDescription.text = u;
    }

    void Start()
    {
        shopping = false;
        for(int i =0;i<shopUIs.Length;i++)
            shopUIs[i].enabled=false;
        vendingTexts = new Text[changeTextsPublic.transform.childCount];
       
        for(int i = 0; i < changeTextsPublic.transform.childCount; i++)
        {
            GameObject temp = changeTextsPublic.transform.GetChild(i).gameObject;
            vendingTexts[i] =temp.GetComponent<Text>();
        }
        changeTextsPublic = null;
    }

    void enterShop()
    {
        var eventSystem = EventSystem.current;
        eventSystem.SetSelectedGameObject(slectedItems[0], new BaseEventData(eventSystem));

        interaction.hideUI(true);
        playerInput.block(true);
        shopUIs[0].enabled = true;
       
        gameHud.enabled = false;

        shopping = true;
        
    }

    void exitShop()
    {
        interaction.hideUI(false);
        playerInput.block(false);
        shopUIs[0].enabled = false;

        gameHud.enabled = true;
        shopping = false;
        
    }//end exitShop()


    public override void OnSubmit()
    {
        if (!shopping)
            enterShop();
    }

    public override void OnCancel()
    {
        if(shopping)
            decrementUI();
    }
   
}
