using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "new shop Inventory", menuName = "shopInventory")]
public class shopInventory : ScriptableObject
{

    [SerializeField]
    Item[] items;
    [SerializeField]
    ushort[] numItems;
    [SerializeField]
    ushort[] maxItems;
    [SerializeField]
    float[] costs;
    

    public ushort getNumItem(ushort i)
    {
        return numItems[i];
    }

    public void lowerNumItem(ushort i,ushort n)
    {
        numItems[i] -= n;
    }


    public Item getItem(ushort i)
    {
        return items[i];
    }

    public float getCost(ushort i)
    {
        return costs[i];
    }

    public void resetInventory()
    {
        for (int i = 0; i < numItems.Length; i++)
        {
            numItems[i] = maxItems[i];
        }
    }

}
